package Opgave3;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DictionaryList<K, V> implements src.opgave02.Dictionary<K, V> {

    // Array af lister. Hver liste er en bucket.
    private List<Entry<K, V>>[] tabel;

    // Antal buckets
    private static final int N = 13;

    // Antal elementer i hele dictionary
    private int size;

    // Constructor
    public DictionaryList() {
        tabel = new ArrayList[N];
        for (int i = 0; i < N; i++) {
            tabel[i] = new ArrayList<>();
        }
        size = 0;
    }

    // Hjælpemetode: finder bucket-indeks ud fra key
    private int hashIndex(K key) {
        return Math.abs(key.hashCode() % N);
    }

    @Override
    public V get(K key) {
        if (key == null) {
            return null;
        }

        int index = hashIndex(key);
        List<Entry<K, V>> bucket = tabel[index];

        for (Entry<K, V> entry : bucket) {
            if (entry.getKey().equals(key)) {
                return entry.getValue();
            }
        }

        return null;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public V put(K key, V value) {
        Objects.requireNonNull(key, "key må ikke være null");
        Objects.requireNonNull(value, "value må ikke være null");

        int index = hashIndex(key);
        List<Entry<K, V>> bucket = tabel[index];

        // Hvis key allerede findes, overskriv value og returnér gammel value
        for (Entry<K, V> entry : bucket) {
            if (entry.getKey().equals(key)) {
                V oldValue = entry.getValue();
                entry.setValue(value);
                return oldValue;
            }
        }

        // Hvis key ikke findes, tilføj nyt par
        bucket.add(new Entry<>(key, value));
        size++;
        return null;
    }

    @Override
    public V remove(K key) {
        if (key == null) {
            return null;
        }

        int index = hashIndex(key);
        List<Entry<K, V>> bucket = tabel[index];

        for (int i = 0; i < bucket.size(); i++) {
            Entry<K, V> entry = bucket.get(i);
            if (entry.getKey().equals(key)) {
                V value = entry.getValue();
                bucket.remove(i);
                size--;
                return value;
            }
        }

        return null;
    }

    @Override
    public int size() {
        return size;
    }

    // Indre klasse der gemmer et key-value-par
    private static class Entry<K, V> {
        private K key;
        private V value;

        public Entry(K key, V value) {
            this.key = key;
            this.value = value;
        }

        public K getKey() {
            return key;
        }

        public V getValue() {
            return value;
        }

        public void setValue(V value) {
            this.value = value;
        }
    }
}
