package Opgave01;

import java.util.HashSet;

public class App {
    public static void main(String[] args) {
        HashSet<Bil> Biler = new HashSet<>();
        Bil bil1 = new Bil("1234abcd","Tesla","x","Rød");
        Bil bil2 = new Bil("1234abcd","Tesla","x","Rød");
        Bil bil3 = new Bil("1a2b3c4d","Ford","GT","Sort");
        Bil bil4 = new Bil("1b2a3d4c","Ford","Mustang","Sort/Rød");
        Biler.add(bil1);
        Biler.add(bil2);
        Biler.add(bil3);
        Biler.add(bil4);

        System.out.println("biler i Hashset er: " + Biler.size());

        for (Bil bil : Biler){
            System.out.println(bil.toString());
        }
    }
}
