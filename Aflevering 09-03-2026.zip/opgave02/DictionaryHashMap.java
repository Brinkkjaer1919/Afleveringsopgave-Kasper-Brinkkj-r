package opgave02;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class DictionaryHashMap<K, V> implements src.opgave02.Dictionary<K, V> {

    private Map<K, V>[] tabel;
    private static final int N = 13;
    private int size;

    public DictionaryHashMap() {
        tabel = new HashMap[N];
        for (int i = 0; i < N; i++) {
            tabel[i] = new HashMap<>();
        }
        size = 0;
    }

    private int hashIndex(K key){
        return Math.abs(key.hashCode() % N);
    }

    @Override
    public V get(K key) {
        if (key == null) {
            return null;
        }
        int index = hashIndex(key);
        return tabel[index].get(key);
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public V put(K key, V value) {
        Objects.requireNonNull(key,"key må ikke være null");
        Objects.requireNonNull(value,"value må ikke være null");

        int index = hashIndex(key);
        V oldValue = tabel[index].put(key,value);

        if (oldValue == null) {
            size++;
        }

        return oldValue;
    }

    @Override
    public V remove(K key) {
        if (key == null){
            return null;
        }
        int index = hashIndex(key);
        V removeValue = tabel[index].remove(key);

        if (removeValue != null){
            size--;
        }

        return removeValue;
    }

    @Override
    public int size() {
        return size;
    }

}
