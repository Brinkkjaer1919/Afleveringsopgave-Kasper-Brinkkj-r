package opgave02;

    public class App {

        public static void main(String[] args) {

            src.opgave02.Dictionary<Integer, String> dictionary = new DictionaryHashMap<>();

            System.out.println("Er dictionary tom? " + dictionary.isEmpty());

            System.out.println("Antal elementer: " + dictionary.size());

            dictionary.put(8, "Hans");
            dictionary.put(3, "Viggo");

            System.out.println("\nEfter indsættelse:");

            System.out.println("Er dictionary tom? " + dictionary.isEmpty());
            System.out.println("Antal elementer: " + dictionary.size());

            System.out.println("\nHenter værdi for key 8:");
            System.out.println(dictionary.get(8));

            dictionary.put(7, "Bent");
            dictionary.put(2, "Lene");

            System.out.println("\nEfter flere indsættelser:");
            System.out.println("Antal elementer: " + dictionary.size());

            System.out.println("\nFjerner key 3:");
            System.out.println("Fjernet værdi: " + dictionary.remove(3));

            System.out.println("Antal elementer nu: " + dictionary.size());

            System.out.println("\nTester get igen:");
            System.out.println("Key 7: " + dictionary.get(7));
            System.out.println("Key 3: " + dictionary.get(3));
        }
    }
